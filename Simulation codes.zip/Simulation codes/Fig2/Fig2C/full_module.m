function dy= full_module(t,y)
global d1;global d2;
global c1;global c2;
global p1;global p2;
global q1;global q2;
global b1;global b2;
global e1;global m1;global am;global k;
global H1;global Iin;global h1;
global g1;global kbg1;global kbg2;
global L1;global L2;
global afa;global beta;

dy=zeros(6,1);  
%%%%%%%%%%%%%%%%%%%%%%
A1=afa*y(3)/(beta+y(3))*am/(kbg1+k*y(1))/L1*log((H1+Iin)/(H1+Iin*exp(L1*(-kbg1-k*y(1)))));
A2=afa*y(4)/(beta+y(4))*am/(kbg2+k*y(2))/L2*log((H1+Iin)/(H1+Iin*exp(L2*(-kbg2-k*y(2)))));
OMIGA1=y(6)*b1*y(3)+(1-y(6))*b2*y(4);
%%%%%%%%%%%% main equations %%%%%%%%%%%
dy(1)=A1*y(1)-y(1)*d1-c1*y(3)*y(1)/(1+p1*y(1)+q1*y(3));%X1
dy(2)=A2*y(2)-y(2)*d2-c2*y(4)*y(2)/(1+p2*y(2)+q2*y(4));%X2
dy(3)=-y(3)*d1+c1*y(3)*y(1)/(1+p1*y(1)+q1*y(3))-y(3)*b1*y(5)*y(6)/(1+h1*OMIGA1); %Y1
dy(4)=-y(4)*d2+c2*y(4)*y(2)/(1+p2*y(2)+q2*y(4))-y(4)*b2*y(5)*(1-y(6))/(1+h1*OMIGA1); %Y2
dy(5)=y(5)*(e1*OMIGA1/(1+h1*OMIGA1)-m1);                                               %Z
dy(6)=g1*y(6)*(1-y(6))*e1*(b1*y(3)-b2*y(4))/((1+h1*OMIGA1)^2);                      %theta
end

