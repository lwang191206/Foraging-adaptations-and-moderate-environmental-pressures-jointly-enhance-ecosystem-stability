
% 最大最小值法绘制分岔图（X1对g）
clear; clc; close all;

% 定义系统参数（根据实际模型设置）
d1=0.1;d2=0.1;c1=0.3;c2=0.35;h0=1;b1=0.25;b2=0.3;
e1=0.5;m1=0.1;am=1; k=0.2;H1=1;beta=0.1;
w=0.5;h1=1;kbg1=0.5;kbg2=0.5;afa=0.75;Iin=1;L1=1;L2=1;

% 分岔参数
g_values = 0:0.005:1;  % 避免g=0
transient = 3000;          % 瞬态时间
tspan = [0 10000];         % 时间区间
tolerance = 1e-3;          % 稳态判定阈值

% 初始条件（28维变量，前6为状态变量，其余参数设定为0或合理初值）
ox1=6; ox2=5; oy1=2; oy2=1;oz1=4; ou1=0.5;
y0 = [ox1; ox2; oy1; oy2; oz1; ou1]; 

% 存储分岔数据
bifurcation = [];

% ODE求解选项
options = odeset('RelTol', 1e-4, 'AbsTol', 1e-7, 'MaxStep', 0.5);

% 主循环
for i = 1:length(g_values)
    g = g_values(i);
    
    if i > 1
        y0 = y(end, :)';
    end

    try
        [t, y] = ode15s(@(t, y) Kucao(t,y,d1,d2,c1,c2,h0,w,b1,b2, h1,e1,m1,g,am,kbg1,kbg2, k,L1,L2,H1,Iin,afa,beta), tspan, y0, options);
    catch
        fprintf('求解失败：g=%.3f\n', g);
        continue;
    end

    if isempty(y) || any(isnan(y(:))) || any(isinf(y(:)))
        fprintf('无效解：g=%.3f\n', g);
        continue;
    end

    mask = t > transient;
    z_trunc = y(mask, 5);  % X1变量

    if isempty(z_trunc)
        fprintf('警告：g=%.3f 无有效数据\n', g);
        continue;
    end

    if std(z_trunc) < tolerance && (max(z_trunc) - min(z_trunc)) < 1e-3
        pks = mean(z_trunc) * [1; 1];
    else
        [pks_max, ~] = findpeaks(z_trunc, 'MinPeakProminence', 0.5*tolerance);
        [pks_min, ~] = findpeaks(-z_trunc, 'MinPeakProminence', 0.5*tolerance);
        pks_min = -pks_min;
        pks = [pks_max; pks_min];
    end

    if ~isempty(pks)
        bifurcation = [bifurcation; g * ones(size(pks)), pks];
    end

    if mod(i, 10) == 0
        fprintf('进度：%d/%d\n', i, length(g_values));
    end
end

% 绘制分岔图
figure;
if ~isempty(bifurcation)
    scatter(bifurcation(:,1), bifurcation(:,2), 3, 'b', 'filled', 'MarkerEdgeAlpha', 0.8, 'MarkerFaceAlpha', 0.8);
    ax = gca;
    ax.LineWidth = 2;
    ax.FontName = 'Arial';
    ax.FontSize = 18;
    xlim([min(g_values), max(g_values)]);
    box on;
   xlim([0, 0.8]);
    xticks([0 0.2 0.4 0.6 0.8]);
    ylabel('Z', 'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
xlabel('it\g', 'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
else
    disp('无有效数据可绘制。');
end
set(gca, 'Fontname', 'Arial', 'Fontweight', 'bold', 'linewidth', 3, 'FontSize', 20);
% 定义ODE系统函数（g为参数）
function dy = Kucao(~,y,d1,d2,c1,c2,h0,w,b1,b2, h1,e1,m1,g,am,kbg1,kbg2, k,L1,L2,H1,Iin,afa,beta)
dy=zeros(6,1);
A1=afa*y(3)/(beta+y(3))*am/(kbg1+k*y(1))/L1*log((H1+Iin)/(H1+Iin*exp(-L1*(kbg1+k*y(1)))));
A2=afa*y(4)/(beta+y(4))*am/(kbg2+k*y(2))/L2*log((H1+Iin)/(H1+Iin*exp(-L2*(kbg2+k*y(2)))));
OMIGA1=y(6)*b1*y(3)+(1-y(6))*b2*y(4);
%equations
dy(1)=A1*y(1)-y(1)*d1-c1*y(3)*y(1)/(1+h0*c1*y(1)+h0*w*y(3));%X1
dy(2)=A2*y(2)-y(2)*d2-c2*y(4)*y(2)/(1+h0*c2*y(2)+h0*w*y(4));%X2

dy(3)=c1*y(3)*y(1)/(1+h0*c1*y(1)+h0*w*y(3))-y(3)*d1-y(3)*b1*y(5)*y(6)/(1+h1*OMIGA1);
dy(4)=c2*y(4)*y(2)/(1+h0*c2*y(2)+h0*w*y(4))-y(4)*d2-y(4)*b2*y(5)*(1-y(6))/(1+h1*OMIGA1);

dy(5)=y(5)*(e1*OMIGA1/(1+h1*OMIGA1)-m1);

dy(6)=g*y(6)*(1-y(6))*e1*(b1*y(3)-b2*y(4))/((1+h1*OMIGA1)^2);


%y(18)=g;y(16)=e1;y(13,14)=b1,b2,y(15)=h1;y(17)=m1;y(7,8)=d1,d2
%y(9,10)=c1.c2,y(11)=h0;y(12)=w;y(19)=am
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
end
