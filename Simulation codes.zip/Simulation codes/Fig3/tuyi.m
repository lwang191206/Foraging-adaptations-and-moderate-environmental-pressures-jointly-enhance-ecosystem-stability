% w=0.5;    q1=w; q2=w;                % 干扰强度  0.5-1
for rr=linspace(0.37,1,127) 
ox1=6; ox2=5; oy1=2; oy2=1;oz1=4; ou1=0.5;     
d1=0.1;d2=0.1;c1=0.3;c2=0.35;h0=1;b1=0.25;b2=0.3;
e1=0.5;m1=0.1;am=1; k=0.2;H1=1;beta=0.1;
%%%%%%%%%%%%%%%%%%%%%%%%%%
g1=0.2;afa=0.75;h1=1;w=rr;
kbg1=0.5;kbg2=0.5;
Iin=1;
L1=1;L2=1;
[t,y]=ode45('Kucao',[0 5000],[ox1;ox2;oy1;oy2;oz1;ou1;
                               d1;d2;c1;c2;h0;w;b1;b2;
                               h1;e1;m1;g1;am;kbg1;kbg2;
                               k;L1;L2;H1;Iin;afa;beta]);     
[Xmax]=getmax(y(:,5));
gColor = [55, 173, 55] ./ 255;
plot(rr, Xmax, '.', 'Color', gColor, 'MarkerSize', 4);
xlabel('\itw','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
ylabel('Z','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
hold on
ylim([0.4 1])
yticks(0.4:0.2:1);
xlim([0.4 1]);
xticks(0.4:0.2:1);
set(gca, 'Fontname', 'Arial', 'Fontweight', 'bold', 'linewidth', 2, 'FontSize', 20);
clear Xmax
subplot(2,1,2)                     
[Xmax]=getmax(y(:,6));
plot(rr,Xmax,'b.','markersize',4)
xlabel('\itw','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
ylabel('\theta' ,'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
hold on
clear Xmax
end
ylim([0.4 1])
yticks(0.4:0.2:1);
xlim([0.4 1]);
xticks(0.4:0.2:1);
set(gca, 'Fontname', 'Arial', 'Fontweight', 'bold', 'linewidth', 2, 'FontSize', 20);