function output=multicompete_U(~,rho,dj,cj,pj,qj,bij,ei,mi,gi,kbgj,kj,Iin,Lj,a_max,H1,hi,alfa,beta,ni,nj)
% rho(rho<1e-12)=0; %rho=output rho=rho0;
Xj=rho(1:nj);
Yj=rho(nj+1:nj*2);
Zi=rho(nj*2+1:nj*2+ni);
thetaij=reshape(rho(nj*2+ni+1:end),ni,nj-1);%转置表示theta
thetaij_1=[thetaij,1-sum(thetaij,2)];%每次更新最后一列，组合成完整矩阵
omigai1=sum(thetaij_1.*bij.*repmat(Yj',ni,1),2);
omigai=1+hi.*omigai1;
Ioutj=Iin.*exp((-kbgj-kj.*Xj).*Lj);
aj=(a_max./((kbgj+kj.*Xj).*Lj)).*log((H1+Iin)./(H1+Ioutj));
output(1:nj,1)=aj.*Xj.*(alfa.*Yj./(beta+Yj))-dj.*Xj-(cj.*Xj.*Yj)./(1+pj.*Xj+qj.*Yj);%苦草 冬芽转换为苦草
% output(1:nj,1)=aj.*Xj.*-dj.*Xj-(cj.*Xj.*Yj)./(1+pj.*Xj+qj.*Yj);%冬芽不转换为苦草
output(nj+1:nj*2,1)=(cj.*Xj.*Yj)./(1+pj.*Xj+qj.*Yj)-dj.*Yj-Yj.*sum(thetaij_1.*bij.*repmat(Zi,1,nj)./repmat(omigai,1,nj),1)';%冬芽
output(nj*2+1:nj*2+ni,1)=(ei.*(omigai1./omigai)-mi).*Zi;%候鸟
the1=(thetaij.*repmat(gi.*ei./(omigai.^2),1,nj-1)).*(2.*bij(:,1:nj-1).*repmat(Yj(1:nj-1)',ni,1)-repmat(2.*bij(:,nj).*Yj(nj),1,nj-1)-...
    repmat(sum(thetaij.*bij(:,1:nj-1).*repmat(Yj(1:nj-1)',ni,1),2),1,nj-1)-(bij(:,1:nj-1).*repmat(Yj(1:nj-1)',ni,1)-repmat(2.*bij(:,nj).*Yj(nj),1,nj-1)).*repmat(sum(thetaij,2),1,nj-1));
output(nj*2+ni+1:nj*2+ni+ni*(nj-1),1)=the1(:);%thetaij
end


