% 数据和颜色
months = {'10', '11', '12', '1', '2', '3'};


% 定义物种数据
quantities_list_1 = [
1	175	774	289	122	257
0	44	325	65	76	52
3 	537 	387 	458 	94 	26 
0 	50 	443 	1130 	110 	13 
0 	16 	20 	21 	14 	11 
0 	36 	57 	115 	265 	197 
11 	12 	12 	108 	368 	51 
3 	19 	957 	488 	285 	119 
0 	60 	322 	280 	226 	65 
0 	16 	47 	171 	376 	82 
0 	20 	196 	95 	79 	79 
];

quantities_list_2 = [
    0	20881	9711	1114	273	588
2	2763	416	510	224	9
183 	13767 	7396 	3295 	1062 	220 
0 	1713 	35546 	12163 	771 	343 
268 	510 	890 	514 	66 	9 
0 	211 	946 	273 	20 	0 
3 	454 	3221 	888 	826 	145 
4 	1613 	5649 	3577 	1499 	229 
38 	757 	745 	405 	231 	114 
38 	751 	164 	11 	96 	15 
0 	2045 	4689 	1992 	1940 	72 
];
quantities_list_3 = [
    100	4256	15830	2991	668	425
48	206	9957	2554	506	582
1573 	7856 	4289 	3444 	1446 	148 
301 	605 	18701 	6012 	4023 	846 
18 	685 	1061 	462 	614 	57 
16 	978 	2845 	825 	995 	198 
9 	1067 	13584 	2440 	3163 	156 
4 	1613 	5649 	3577 	1499 	229 
264 	7789 	3173 	3281 	766 	379 
417 	4197 	7305 	2001 	959 	940 
155 	1310 	3009 	1723 	943 	108 
];


% 定义 8 种颜色，对应 8 个物种
colors = [
   0, 0.447, 0.741;   % 蓝色
   % 0.85, 0.325, 0.098; % 红橙色
    0.929, 0.694, 0.125; % 黄色
    %0.494, 0.184, 0.556; % 紫色
    0.466, 0.674, 0.188; % 绿色
   %0.301, 0.745, 0.933; % 青色
  % 0.635, 0.078, 0.184; % 深红色
    %0.2, 0.2, 0.2;        % 灰黑色
];

% 物种英文名称 (用于图例)
species_titles = {
    'Grus leucogeranus',   % 白鹤
    'Cygnus columbianus',  % 小天鹅
    'Anser cygnoides',     % 鸿雁
   
};

% 年份
years = {
    '2011', '2012', '2013', '2014', '2015', ...
    '2016', '2017', '2018', '2019', '2020', '2021','2022'
};

% 创建图形
figure;

subplot(2,1,1);
hold on;
% 用于存储每条曲线的句柄
subplot(2,1,1);
plot_handles = [];

% 将所有物种的数据放入一个 cell 数组，便于循环处理
all_quantities = {quantities_list_1, quantities_list_2, quantities_list_3};

% 循环绘制每个物种的数据
for species_idx = 1:length(all_quantities)
    quantities = all_quantities{species_idx};  % 获取当前物种数据
    for i = 1:size(quantities, 1)
        x_values = (i-1)*6 + (1:6);  % 计算x轴的位置
        % 绘制数据，并存储每条曲线的句柄
        h = plot(x_values, quantities(i,:), '-', 'LineWidth', 2, 'MarkerSize', 10, 'Color', colors(species_idx, :));  
        if i == 1  % 只存储一次句柄
            plot_handles(species_idx) = h;
        end
        % 如果不是最后一年，绘制年份之间的连接曲线（3月到下一年的10月）
        if i < size(quantities, 1)
            x_connect = [x_values(end), x_values(end) + 1];  % x轴连接点
            y_connect = [quantities(i, end), quantities(i+1, 1)];  % y轴连接点
            plot(x_connect, y_connect, '-', 'Color', colors(species_idx, :), 'LineWidth', 2);  % 使用实线绘制连接线
        end
    end
end
% 添加年份分界线
for i = 1:(size(quantities_list_1, 1) - 1)
    x_boundary = i*6 + 0.5;
    plot([x_boundary x_boundary], [0 30000], '--k', 'LineWidth', 1, 'HandleVisibility', 'off');
end

% 设置 x 轴刻度和标签
xticks(1:(6*length(years)));
xticklabels(repmat({''}, 1, 6*length(years)));  % 不显示横坐标的默认标签

% 标注每年的年份
year_positions = (0:length(years)-1) * 6 + 0.5;  % 年份的起始位置从0开始
for i = 1:length(years)
    text(year_positions(i), -max(max(cell2mat(all_quantities))) * 0.1, years{i},  ...
        'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 15, 'HorizontalAlignment', 'center');
end


% 设置坐标轴范围和刻度
xlim([1, length(years) * 6-6]);  % 调整 x 轴范围以消除多余的空白
ylim([0 40000]);  % 保持 y 轴范围不变
% 添加网格和图例
box on;

legend(plot_handles, species_titles,  'Fontname', 'Arial', 'Fontweight', 'bold','FontSize', 16, 'Location', 'north', 'Orientation', 'horizontal', ...
    'NumColumns', 4, 'Box', 'off');  % 使用 'NumColumns' 设置两行，每行4个物种
% 设置坐标轴属性
set(gca, 'Fontname', 'Arial', 'Fontweight', 'bold', 'linewidth', 2, 'FontSize', 16);


hold off;
