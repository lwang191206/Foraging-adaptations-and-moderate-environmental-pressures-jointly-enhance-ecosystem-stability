%% 使用候鸟数据绘图
clc
clear
%% 
g=0:0.05:1;
kbg=0:0.05:1;
load g+kbg+houniao.mat  %


%% 
for i=1:21
        for j=1:21
        hn(i,j)=mean(nonzeros(chongfu_houniao{i,j}))/16;%过滤每个子矩阵的非0元素并求均值储存再hn中   
          HN(i,j)=std(nonzeros(chongfu_houniao{i,j})/16);% 求标准差
        end
end

%% 
%去掉第 1 和第 20 到第 21 列
columns_to_remove = [1];
hn(:, columns_to_remove) = [];
HN(:, columns_to_remove) = [];
kbg(columns_to_remove) = [];

% 去掉第一行
%hn(1, :) = [];
%HN(1, :) = [];
%g(1) = [];

%hn(1,:)=[];%将含有nan的行删除，注意此时对应的参数g也应舍弃这些点   %%这是矩阵第1行到所有列中去除NAN的意思吗？）
%hn(:,1:3)=[];%将含有nan的列删除，注意此时对应的参数w也应舍弃这些点   %% 为什么这个是所有行的1到3列呀）
%HN(1,:)=[];%将含有nan的行删除，注意此时对应的参数g也应舍弃这些点  %%（同上）
%HN(:,1:3)=[];%将含有nan的列删除，注意此时对应的参数w也应舍弃这些点

%%
%g(:,1)=[]; 
%w(:,1:3)=[];
%% 
figure(1),
set(gca,'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20, 'LineWidth',3);
subplot(2,3,1)
surf(kbg,g,hn,'LineStyle','none'),view(2),colormap("parula"),axis tight%先绘制均值的三维图俯视视角
colorbar('v')%固定色阶栏的位置
%clim([0 1]);
clim([0 1]); % 设置颜色范围
c = colorbar; % 获取 colorbar 对象
c.Ticks = 0:0.2:1; % 设置色标刻度间隔为 0.2
c.TickLabels = arrayfun(@num2str, c.Ticks, 'UniformOutput', false); % 可选：自定义刻度标签
hold on
plot3([0 1],[0.5 0.5],[1 1],"--",'LineWidth',2,Color="k");%在三维空间中绘制要在下一张图上要展示的那条线的位置
set(gca,'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20, 'LineWidth',3);
h1 = gca; % 获取当前轴
%xlabel('\itkbg ','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20)
%ylabel("\it{g}",'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20)
%text('String','Units','normalized','position',[0.1 0.9],'FontSize',15,'FontWeight','bold','Color','w','FontName','Times New Roman',FontAngle='italic')
ylim([0.05 1])
yticks([0.05 0.35 0.65 0.85 1]);
xlim([0.5 1]);
xticks(0.5:0.25:1);
%xticks([0.05 0.45 0.85 1]);


subplot(2,3,4)
gm=0.5;%0.55时的均值与标准差,根据需求更改g-----横线
hn_x=kbg; hn_y=hn(find(g==gm),:)%g=0.55时的均值与标准差
plot(hn_x,hn_y,'b', 'LineWidth', 2),axis tight;hold on%首先绘制g=0.55的均值
%然后使用fill函数填充均值上下一个标准差范围内的曲线区域。
h=fill([hn_x ,fliplr(hn_x)],[(hn_y-HN(find(g==gm),:)), fliplr((hn_y+HN(find(g==gm),:)))],'b','edgecolor','none','FaceAlpha',0.15);hold on 
set(gca,'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20, 'LineWidth',3);
h2 = gca; % 获取当前轴
xlabel('\itL(\its = 0.5)', 'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);

%ylabel("Persistence",'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20)
%text('String','position',[0.1 0.9],'FontSize',15,'FontWeight','bold','Color','k','FontName','Times New Roman',FontAngle='italic')
ylim([0 1])
yticks(0:0.25:1);
xlim([0.5 1]);
xticks(0.5:0.25:1);
%xticks([0.05 0.45 0.85 1]);

%%
% 调整子图位置以对齐
% 获取子图 1 和 2 的位置
pos1 = get(h1, 'Position');
pos2 = get(h2, 'Position');
% 设置子图 2 的位置与子图 1 对齐
pos2(3) = pos1(3); % 宽度对齐
set(h2, 'Position', pos2);

% 添加 colorbar 后调整子图 1 的宽度
colorbar_width = 0.0001; % 假设 colorbar 占用 5% 的宽度
pos1(3) = pos1(3) - colorbar_width; % 调整子图 1 的宽度
set(h1, 'Position', pos1);

box on