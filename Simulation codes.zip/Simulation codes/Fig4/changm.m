clear
clc
ni=16;nj=16;
cf=50; % 重复50次
%% 设置储存空间
chongfu_kucao=cell(21);chongfu_houniao=cell(21); % gii，0:0.01:1，cell(101)
cf_kucao=zeros(cf,1);cf_houniao=zeros(cf,1); % 存储每次重复的结果
%% 代码
gii=0:0.05:1;alfajj=0.5:0.05:1.5; % 变动的间隔
for g1=1:length(gii) % 纵坐标，变动的参数
    gi=gii(g1); % 相当于一个盒子，第多少个参数
    for alfa1=1:length(alfajj) % 横坐标，变动的参数
        alfaj=alfajj(alfa1); % 确定出芽率变量
        for i=1:cf
            %% 参数
            cj=unifrnd(0.25,0.4,nj,1); % 繁殖率
            pj=cj;
            bij=unifrnd(0.2,0.35,ni,nj); % 随机矩阵
            dj=unifrnd(0.1,0.1,nj,1); % 苦草死亡率
            ei=unifrnd(0.5,0.5,ni,1); % 候鸟同化率
            mi=unifrnd(0.1,0.1,ni,1); % 候鸟死亡率
            kj=unifrnd(0.2,0.2,nj,1); % 光子灭绝率
            a_max=unifrnd(1,1,nj,1);
            H1=unifrnd(1,1,nj,1);
            beta=0.1;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            qj=unifrnd(0.5,0.5,nj,1); % 干扰强度
            hi=unifrnd(1,1,ni,1); % 处理时间
           % alfa=0.75;                  %出芽率 交互
            kbgj=unifrnd(0.5,0.5,nj,1); % 浑浊度
            Iin=unifrnd(1,1,nj,1); % 光强度
            Lj=unifrnd(1,1,nj,1); % 水位
            %% 状态变量初始值
            Xj=randi([5,6],nj,1);
            Yj=randi([1,2],nj,1);
            Zi=randi([3,5],ni,1);
            theta_ij=unifrnd(1/nj,1/nj,ni,nj);theta_ij2=theta_ij(:,1:nj-1);thetaij=theta_ij2(:);
            %% 运算
            rho0=[Xj;Yj;Zi;thetaij;]; % 初始值
            t0=[1:20000];
            [t1,rho]=ode45(@(t,rho)multicompete_U(t,rho,dj,cj,pj,qj,bij,ei,mi,gi,kbgj,kj,Iin,Lj,a_max,H1,hi,alfaj,beta,ni,nj),t0,rho0); % 将afa替换为afaj
            t01=length(t1);
            kucao=length(find(sum(rho(t01(end)-199:t01(end),1:nj),1)./length(t01(end)-199:t01(end))>10^(-5))); % 苦草最后50代的平均值
            houniao=length(find(sum(rho(t01(end)-199:t01(end),2*nj+1:2*nj+ni),1)./length(t01(end)-199:t01(end))>10^(-5))); % 候鸟最后10代的平均值
            cf_kucao(i)=kucao; % 存储苦草平均值
            cf_houniao(i)=houniao; % 存储候鸟平均值
        end
        chongfu_kucao{g1,alfa1}=cf_kucao; % 存储每次重复的苦草平均值
        chongfu_houniao{g1,alfa1}=cf_houniao; % 存储每次重复的候鸟平均值
    end
end
subplot(1,2,1);plot(t1,rho(:,1:nj));title('苦草');
subplot(1,2,2);plot(t1,rho(:,2*nj+1:2*nj+ni));title('候鸟');
