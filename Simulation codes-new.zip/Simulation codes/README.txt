ACCESS INFORMATION
Data from:Foraging adaptations and moderate environmental pressures jointly enhance the stability of waterbird-vegetation antagonistic networks

DATA & CODE FILE OVERVIEW
This data repository consists of 2 data file and 23 code scripts, and this README document, with the following data and code filenames and variables

Data files and variables
1. [Model & empirical data in Fig.5.xlsx]
2. [Empirical data in Fig. 6.xlsx]

Code scripts and workflow

Regarding Figure 2
(1)Execute the code bifurcation_Z_g.m to obtain Fig. 2A;
(2)Execute the code run_lyapunov.m to obtain Fig. 2B;
(3)Execute the code shixu.m to obtain Fig. 2C.

Regarding Figure 3
(1)Execute the script kucao_bifur_r_get.m, and use the maximum-minimum value method in getmax.m along with the simplified system model Kucao.m to generate Fig.3 (A–H).

Regarding Figure 4
(1)Access the differential equation solver implemented in multicompete_U.m;
(2)Execute the script changm.m to perform numerical simulations under different values of w, h, α, Kbg, Iin, and L, in order to determine the number of surviving species;
(3)Execute the script houniao.m to calculate the average species persistence of overwintering herbivorous waterbirds from the previous step, in order to generate the subplots of Figure 4 .
(4)Use the script plot.m to generate graphical outputs, with each parameter setting corresponding to a separate subplot saved as an individual .fig file, and then combine the 12 subplots to form Figure 4.

Regarding Figure 5
(1)Execute the code dynamic.m to obtain Fig. 5A;
(2)Execute the code zongzhexian.m to obtain Fig. 5B;
(3)Execute the code monixiangwei.m to obtain Fig. 5(C,E,G);
(4)Execute the code shicexiangwei.m to obtain Fig. 5(D,F,H).

Regarding Figure 6
(1)Figure 6 (A, C, E, G) is obtained by following the same code procedure as Figure 4；
(2)Execute the code houniaoshuiwei.m to obtain Fig. 6B;
(3)Execute the code houniaotoumingdu.m to obtain Fig. 6D;
(4)Execute the code kucaoshuiwei.m to obtain Fig. 6F;
(5)Execute the code kucaotoumingdu.m to obtain Fig. 6H.


Figures Summary
1. Figure 2A: Bifurcation diagram;
2. Figure 2B: Lyapunov exponent spectrum; 
3. Figure 2C-D: time series of waterbird population and foraging effort.
4. Figure 3: Bifurcation diagrams.
5. Figure 4: Community persistence (mean ± standard deviation, based on 50 replicates) varies with adaptation intensity (S) and key biotic (w, h, α) and abiotic (Kbg, Iin, L) factors in the complex HWVT system.
6. Figure 5A: Simulated population density dynamics over time based on the four-habitat adaptive network model.
7. Figure 5B: Field survey data of three overwintering herbivorous waterbird species in four dish-shaped lakes of Poyang Lake.
8. Figure 5 (C, E, G): Phase angle analyses between any two waterbird species based on simulation data.
9. Figure 5 (D, F, H): Phase angle analyses between any two waterbird species based on empirical data.
10. Figure 6 (A, C, E, G): Predicted by the adaptive network model, these panels show the relationships between target species (i.e., overwintering herbivorous waterbirds Z and Vallisneria natans X) and key abiotic factors (i.e., water level L and turbidity Kbg).
11. Figure 6 (B, D, F, H): Empirical data analysis.

SOFTWARE VERSIONS
All numerical simulations are via ode45 in Matlab R2023a.