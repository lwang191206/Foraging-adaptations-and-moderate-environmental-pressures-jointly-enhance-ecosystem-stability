% 设置网络规模，8个候鸟，9个苦草
ni = 3;  % 候鸟物种数量
nj = 4;  % 苦草物种数量
% 调整后的参数设定
dj = unifrnd(0.001, 0.001, nj, 1);  % 增加苦草死亡率
cj = unifrnd(0.75, 0.78, nj, 1);    % 调整繁殖率，增强波动
pj = cj;  % 苦草繁殖率和种子繁殖率保持相同
bij = unifrnd(0.45, 0.65, ni, nj);  % 增强物种间相互作用强度
ei = unifrnd(0.85, 0.9, ni, 1);      % 同化率保持较高水平
mi = unifrnd(0.01, 0.01, ni, 1);    % 增加候鸟死亡率，增强波动
kj = unifrnd(0.1, 0.1, nj, 1);      % 光子灭绝率保持不变
a_max = unifrnd(1, 1, nj, 1);       % 光合作用能力保持不变
H1 = unifrnd(0.9, 1, nj, 1);        % 调低光合作用效率，增加波动
beta = 0.1;                        % 增加苦草与候鸟相互作用调节参数
gi = unifrnd(0.75, 0.75, ni, 1);    % 候鸟适应率保持适中
hi = unifrnd(1, 1, ni, 1);          % 候鸟处理时间保持不变
alfa = 0.75;                        % 苦草出芽率保持不变
kbgj = unifrnd(0.35, 0.55, nj, 1);  % 浑浊度保持相同
Iin = unifrnd(1, 1, nj, 1);         % 光强度保持不变
Lj = unifrnd(1, 2, nj, 1);          % 水位保持不变
qj = unifrnd(0.58, 0.78, nj, 1);      % 增加环境干扰，增强波动

% 初始状态变量的随机扰动增大
Xj = randi([1, ], nj, 1);   % 增加初始苦草数量范围
Yj = randi([2, ], nj, 1);  % 增加苦草种子初始数量范围
Zi = randi([3, 6], ni, 1);   % 候鸟初始数量范围
theta_ij = unifrnd(0.1/nj, 0.5/nj, ni, nj);  % 增大相互作用的初始随机性
theta_ij2 = theta_ij(:, 1:nj-1); 
thetaij = theta_ij2(:);

% 调整后的初始状态变量组合
rho0 = [Xj; Yj; Zi; thetaij];

%% 使用ODE45求解系统
t0 = [16000:18:20000];  % 时间区间保持适中
 % 3960 天，从第 0 天开始到第 3959 天
% 时间区间保持适中
tic
[t1, rho] = ode45(@(t,rho)multicompete_U(t, rho, dj, cj, pj, qj, bij, ei, mi, gi, kbgj, kj, Iin, Lj, a_max, H1, hi, alfa, beta, ni, nj), t0, rho0);
toc



%% 提取仅参与绘制的候鸟数据并保存
selected_birds = [1, 2, 3];  % 选择参与绘制的候鸟索引
bird_data = rho(:, 2*nj + selected_birds);  % 提取指定候鸟数据

% 保存为CSV文件
csvwrite('selected_bird_data.csv', bird_data);

%% 绘制候鸟种群随时间变化的图
figure;

% 手动选择8种不同的颜色，确保不重复使用蓝色
colors = [
    0, 0.447, 0.741;   % 蓝色
   % 0.85, 0.325, 0.098; % 红橙色
    0.929, 0.694, 0.125; % 黄色
   % 0.494, 0.184, 0.556; % 紫色
    0.466, 0.674, 0.188; % 绿色
   % 0.301, 0.745, 0.933; % 青色
   % 0.635, 0.078, 0.184; % 深红色
    %0.2, 0.2, 0.2;        % 灰黑色
];

subplot(2,1,1);
for i = 1:numel(selected_birds)
    plot(t1, bird_data(:, i), 'LineWidth', 2, 'Color', colors(i,:));  % 使用不同颜色绘制每种候鸟
    hold on;
end

% 设置图形外观
set(gca, 'Fontname', 'Arial', 'Fontweight', 'bold', 'linewidth', 2, 'FontSize', 16);
%xlabel('Time', 'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 16);
ylabel('Population density','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 16);
xlim([18000, 20000]);  % 设置x轴范围
xticks(18000:500:20000)
ylim([0, 6]);
yticks(0:2:6)
% 调整legend
legend({'Z1','Z2','Z3'}, 'Location', 'north', ...
    'Orientation', 'horizontal', 'NumColumns', 4, 'Box', 'off', ...
    'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 16);
set(gca, 'Fontname', 'Arial', 'Fontweight', 'bold', 'linewidth', 2, 'FontSize', 18);
hold off;
