% 定义所有物种数据，每一行代表不同年份，每列代表不同月份
% 数据格式：[10月, 11月, 12月, 1月, 2月, 3月]
species_data = {
    % 白鹤
    [1	175	774	289	122	257
0	44	325	65	76	52
3 	537 	387 	458 	94 	26 
0 	50 	443 	1130 	110 	13 
0 	16 	20 	21 	14 	11 
0 	36 	57 	115 	265 	197 
11 	12 	12 	108 	368 	51 
3 	19 	957 	488 	285 	119 
0 	60 	322 	280 	226 	65 
0 	16 	47 	171 	376 	82 
0 	20 	196 	95 	79 	79 
],
    % 小天鹅
    [0	20881	9711	1114	273	588
2	2763	416	510	224	9
183 	13767 	7396 	3295 	1062 	220 
0 	1713 	35546 	12163 	771 	343 
268 	510 	890 	514 	66 	9 
0 	211 	946 	273 	20 	0 
3 	454 	3221 	888 	826 	145 
4 	1613 	5649 	3577 	1499 	229 
38 	757 	745 	405 	231 	114 
38 	751 	164 	11 	96 	15 
0 	2045 	4689 	1992 	1940 	72 
],
    % 鸿雁
    [100	4256	15830	2991	668	425
48	206	9957	2554	506	582
1573 	7856 	4289 	3444 	1446 	148 
301 	605 	18701 	6012 	4023 	846 
18 	685 	1061 	462 	614 	57 
16 	978 	2845 	825 	995 	198 
9 	1067 	13584 	2440 	3163 	156 
4 	1613 	5649 	3577 	1499 	229 
264 	7789 	3173 	3281 	766 	379 
417 	4197 	7305 	2001 	959 	940 
155 	1310 	3009 	1723 	943 	108 
]};
    
% 定义物种配对
%pairings = {[1, 2], [3, 4], [5, 7], [6, 8]};
% [白鹤 vs 白头鹤]、[白枕鹤 vs 灰鹤]、[小天鹅 vs 鸿雁]、[白额雁 vs 豆雁]。

pairings = {[1, 2], [1, 3], [2, 3]};

% 设置采样频率
fs = 1;


% 定义物种名称
species_names = {
    'Grus leucogeranus',   % 白鹤
    'Cygnus columbianus',  % 小天鹅
    'Anser cygnoides',     % 鸿雁
    'Grus vipio',          % 白枕鹤
    };
    


% 创建绘图窗口
figure;

% 遍历每个配对
for k = 1:3
    % 获取当前配对的物种
    idx1 = pairings{k}(1);
    idx2 = pairings{k}(2);

    % 提取物种数据（平铺为一维数组）
    species1 = species_data{idx1}(:);
    species2 = species_data{idx2}(:);

    % 使用 wcoherence 计算相位角
    [~, wcs, ~] = wcoherence(species1, species2, fs);

    % 计算相位角
    phase_angle = angle(wcs);
    phase_degrees = rad2deg(phase_angle(:));

    % 在 subplot 上绘制当前配对的相位角分布
    subplot(2, 2, k);
    polarhistogram(deg2rad(phase_degrees), 18, 'FaceColor', [0.1 0.2 0.9]);  % 使用深蓝色填充
    hold on;

   
  % 设置图形的外圈线和直径线样式
ax = gca;
ax.ThetaTick = [0 90 180 270];  % 仅显示 0°, 90°, 180°, 270°
ax.RAxis.Visible = 'off';  % 隐藏径向网格线和刻度
ax.ThetaColor = 'k';       % 设置角度刻度线为黑色

% 将最外圈的弧线颜色设为黑色，并加粗
ax.LineWidth = 2;  % 设置最外圈线宽为 2
ax.Color = 'none'; % 去除内部网格背景
set(ax, 'ThetaTick', [0 90 180 270], 'RTick', [],'Fontname', 'Arial', 'Fontweight', 'bold',  'FontSize', 12);
% 添加四个象限的半径线，均为黑色并线宽为2
% 0°到90°的径向线
line([0, pi/2], [0, ax.RLim(2)], 'Color', 'k', 'LineWidth', 1);

% 90°到180°的径向线
line([pi/2, pi], [0, ax.RLim(2)], 'Color', 'k', 'LineWidth', 1);

% 180°到270°的径向线
line([pi, 3*pi/2], [0, ax.RLim(2)], 'Color', 'k', 'LineWidth', 1);

% 270°到0°的径向线
line([3*pi/2, 2*pi], [0, ax.RLim(2)], 'Color', 'k', 'LineWidth', 1);

% 设置最外圈为完整的黑色弧线（通过创建一个假象的外圈）
% 注意：Matlab默认的polarplot没有直接控制最外圈弧线的选项
% 因此我们可以通过绘制一个边界弧线来模拟

% 绘制最外层弧线，使用polarplot模拟
hold on;
r = ax.RLim(2) * ones(1, 360); % 定义弧线的半径为最大径向范围
theta = linspace(0, 2*pi, 360); % 定义弧线的角度范围（0°到360°）
polarplot(theta, r, 'k', 'LineWidth', 2); % 绘制黑色外圈弧线
hold off;


  % 设置标题为英文物种名称
  title([species_names{idx1}, ' vs ', species_names{idx2}], 'FontName', 'Arial', 'FontWeight', 'bold', 'FontSize', 14);

end

