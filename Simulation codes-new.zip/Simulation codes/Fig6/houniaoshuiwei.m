% 日照数据矩阵 sunlight
sunlight = [
10
10.68
10.68
10.74
10.77
11.03
11.15
11.65
11.66
11.72
12.04
12.35



];

% 鸟类数量数据矩阵 bird_count
bird_count = [
16.66
28.49
28.71
45.16
28.24
58.9
72.57
49.51
30.58
21.36
26.43
13.23







];

% 将矩阵展平为向量，并确保向量相同长度
x2 = reshape(sunlight, [], 1); % 日照向量
y = reshape(bird_count, [], 1); % 鸟的数量向量

% 创建图表窗口
figure;
subplot(2,3,1)
% 绘制散点图
scatter(x2, y, 60, 'MarkerEdgeColor', 'k', 'MarkerFaceColor', [0.529, 0.808, 0.980], ...
    'LineWidth', 1, 'Marker', 'o', 'MarkerFaceAlpha', 1);
hold on;

% 二次多项式拟合
p2 = polyfit(x2, y, 2); % 二次拟合
yfit2 = polyval(p2, x2); % 计算拟合值

% 为了绘制平滑曲线，生成更多的 x2 值，扩展到 13
smooth_x2 = linspace(min(x2), 13, 1000); % 平滑曲线的 x 轴数据
smooth_yfit2 = polyval(p2, smooth_x2); % 计算平滑曲线的 y 值

% 绘制平滑拟合曲线
plot(smooth_x2, smooth_yfit2, '-r', 'LineWidth', 3);
%xlim=[(10 12.5)];
% 计算 R^2
R2 = corrcoef(y, yfit2);
Rsq2 = R2(1, 2)^2;

% 使用 fitlm 计算显著性 p 值
tbl2 = table(x2, x2.^2, y, 'VariableNames', {'x2', 'x2_squared', 'y'});
mdl2 = fitlm(tbl2, 'y ~ x2 + x2_squared');
p_value2 = mdl2.Coefficients.pValue(2); % 提取线性项的 p 值

% 标注拟合参数
legend_text2 = sprintf('R^2 = %.2f\np = %.2f', Rsq2, p_value2);
legend(legend_text2, 'Location', 'best', 'Interpreter', 'none');
hold off;

% 设置图表属性
ylabel('Density  (ind./m^2)', 'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
xlabel('L (m)', 'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
set(gca, 'Fontname', 'Arial', 'Fontweight', 'bold', 'linewidth', 3, 'FontSize', 20);
box on;
fprintf('拟合方程: y = %.4fx^2 + %.4fx + %.4f\n', p2(1), p2(2), p2(3));
%ylim([0 80])



