% 日照数据矩阵 sunlight
sunlight = [

1.09086
1.04336
1.03767
1.02652
0.772343
0.747158
0.685731
0.668985
0.638435
];

% 鸟类数量数据矩阵 bird_count
bird_count = [

21.36
45.16

28.49
28.24
72.57
45.41
44.83
28.71
16.66







];

% 确保向量相同长度
if length(sunlight) ~= length(bird_count)
    error('Sunlight and bird count data must have the same length.');
end

% 展平为列向量
x2 = reshape(sunlight, [], 1); % 日照向量
y = reshape(bird_count, [], 1); % 鸟类数量向量

% 创建图表窗口
figure;
subplot(2,3,1)
% 绘制散点图
scatter(x2, y, 60, 'MarkerEdgeColor', 'k', 'MarkerFaceColor', [0.529, 0.808, 0.980], ...
    'LineWidth', 1, 'Marker', 'o', 'MarkerFaceAlpha', 1);
hold on;

% 二次多项式拟合
p2 = polyfit(x2, y, 2); % 二次拟合
yfit2 = polyval(p2, x2); % 拟合值

% 生成平滑曲线数据
smooth_x2 = linspace(min(x2), max(x2), 1000); % 平滑曲线的 x 数据
smooth_yfit2 = polyval(p2, smooth_x2); % 计算平滑曲线的 y 数据

% 绘制平滑拟合曲线
plot(smooth_x2, smooth_yfit2, '-r', 'LineWidth', 3);

% 计算 R^2
SST = sum((y - mean(y)).^2); % 总平方和
SSR = sum((yfit2 - mean(y)).^2); % 回归平方和
Rsq2 = SSR / SST; % R^2 计算

% 使用 fitlm 计算显著性 p 值
tbl2 = table(x2, x2.^2, y, 'VariableNames', {'x2', 'x2_squared', 'y'});
mdl2 = fitlm(tbl2, 'y ~ x2 + x2_squared');
p_value2 = mdl2.Coefficients.pValue(3); % 提取二次项的 p 值

% 在命令行窗口输出结果
fprintf('R^2 = %.4f\n', Rsq2);
fprintf('p-value = %.4e\n', p_value2);

% 标注拟合参数
legend_text2 = sprintf('R^2 = %.2f\np = %.2e', Rsq2, p_value2);
legend(legend_text2, 'Location', 'best', 'Interpreter', 'none');

% 设置图表属性
%xlim([min(x2), max(x2)] + [-0.5, 0.5]); % 动态调整横坐标范围
%ylim([min(y), max(y)] + [-500, 500]); % 动态调整纵坐标范围
%ylabel('Population density ', 'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
xlabel(' Kbg(m)', 'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
set(gca, 'Fontname', 'Arial', 'Fontweight', 'bold', 'linewidth', 3, 'FontSize', 20);
box on;
%xlim([10, 12.5]); % 横坐标范围
%xticks([14.9:0.2:15.5]); % 横坐标刻度
%ylim([3000, 11000]); % 横坐标范围
%yticks([3000:2000:11000]); % 横坐标刻度
set(gca,'XDir','reverse');
hold off;
% 输出拟合方程
fprintf('拟合方程: y = %.4fx^2 + %.4fx + %.4f\n', p2(1), p2(2), p2(3));

%%

subplot(2,3,4)
% 绘制散点图
scatter(x2, y, 60, 'MarkerEdgeColor', 'k', 'MarkerFaceColor', [0.529, 0.808, 0.980], ...
    'LineWidth', 1, 'Marker', 'o', 'MarkerFaceAlpha', 1);
hold on;

% 二次多项式拟合
p2 = polyfit(x2, y, 2); % 二次拟合
yfit2 = polyval(p2, x2); % 拟合值

% 生成平滑曲线数据
smooth_x2 = linspace(min(x2), max(x2), 1000); % 平滑曲线的 x 数据
smooth_yfit2 = polyval(p2, smooth_x2); % 计算平滑曲线的 y 数据

% 绘制平滑拟合曲线
plot(smooth_x2, smooth_yfit2, '-r', 'LineWidth', 3);

% 计算 R^2
SST = sum((y - mean(y)).^2); % 总平方和
SSR = sum((yfit2 - mean(y)).^2); % 回归平方和
Rsq2 = SSR / SST; % R^2 计算

% 使用 fitlm 计算显著性 p 值
tbl2 = table(x2, x2.^2, y, 'VariableNames', {'x2', 'x2_squared', 'y'});
mdl2 = fitlm(tbl2, 'y ~ x2 + x2_squared');
p_value2 = mdl2.Coefficients.pValue(3); % 提取二次项的 p 值

% 在命令行窗口输出结果
fprintf('R^2 = %.4f\n', Rsq2);
fprintf('p-value = %.4e\n', p_value2);

% 标注拟合参数
legend_text2 = sprintf('R^2 = %.2f\np = %.2e', Rsq2, p_value2);
legend(legend_text2, 'Location', 'best', 'Interpreter', 'none');

% 设置图表属性
%xlim([min(x2), max(x2)] + [-0.5, 0.5]); % 动态调整横坐标范围
%ylim([min(y), max(y)] + [-500, 500]); % 动态调整纵坐标范围
%ylabel('Population density ', 'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
xlabel(' Kbg(m)', 'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
set(gca, 'Fontname', 'Arial', 'Fontweight', 'bold', 'linewidth', 3, 'FontSize', 20);
box on;
%xlim([10, 12.5]); % 横坐标范围
%xticks([14.9:0.2:15.5]); % 横坐标刻度
%ylim([3000, 11000]); % 横坐标范围
%yticks([3000:2000:11000]); % 横坐标刻度
%set(gca,'XDir','reverse');%翻转
hold off;
% 输出拟合方程
fprintf('拟合方程: y = %.4fx^2 + %.4fx + %.4f\n', p2(1), p2(2), p2(3));
