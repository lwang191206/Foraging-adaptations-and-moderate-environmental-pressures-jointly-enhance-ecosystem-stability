function f=bird_jac(~,X)
% ----------------可变的仿真参数-----------------------
 global  d;
% ----------------阶数---6阶---------------------------
 X1=X(1); X2=X(2); Y1=X(3); Y2=X(4); Z=X(5); TH=X(6);
 Y = [X(7), X(13), X(19), X(25), X(31), X(37);
      X(8), X(14), X(20), X(26), X(32), X(38);
      X(9), X(15), X(21), X(27), X(33), X(39);
      X(10), X(16), X(22), X(28), X(34), X(40);
      X(11), X(17), X(23), X(29), X(35), X(41);
      X(12), X(18), X(24), X(30), X(36), X(42)];
  
 f=zeros(42,1);
 
d1=0.1;d2=0.1;
c1=0.3;c2=0.35;b1=0.25;b2=0.3;
h0=1;e1=0.5;m1=0.1;am=1;
k=0.2;H1=1;beta=0.1;

%%%%%%%%%%%%%%%%%%%%%%%%%%
w=0.5;h1=1;kbg1=0.5;kbg2=0.5;afa=0.75;Iin=1;L1=1;L2=1;
g1=d;

  % equations
A1=am/(kbg1+k*X1)/L1*log((H1+Iin)/(H1+Iin*exp(L1*(-kbg1-k*X1))));
A2=am/(kbg2+k*X2)/L2*log((H1+Iin)/(H1+Iin*exp(L2*(-kbg2-k*X2))));
OMIGA1=TH*b1*Y1+(1-TH)*b2*Y2;
%%%%%%%%%%%% main equations %%%%%%%%%%%
f(1)=afa*Y1/(beta+Y1)*A1*X1-X1*d1-c1*Y1*X1/(1+h0*c1*X1+h0*w*Y1);%X1
f(2)=afa*Y2/(beta+Y2)*A2*X2-X2*d2-c2*Y2*X2/(1+h0*c2*X2+h0*w*Y2);%X2
f(3)=-Y1*d1+c1*Y1*X1/(1+h0*c1*X1+h0*w*Y1)-Y1*b1*Z*TH/(1+h1*OMIGA1); %Y1
f(4)=-Y2*d2+c2*Y2*X2/(1+h0*c2*X2+h0*w*Y2)-Y2*b2*Z*(1-TH)/(1+h1*OMIGA1); %Y2
f(5)=Z*(e1*OMIGA1/(1+h1*OMIGA1)-m1);                                               %Z
f(6)=g1*TH*(1-TH)*e1*(b1*Y1-b2*Y2)/((1+h1*OMIGA1)^2);   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dA1dX1=(Iin*am*k*exp(-L1*(kbg1 + X1*k)))/((H1 + Iin*exp(-L1*(kbg1 + X1*k)))*(kbg1 + X1*k)) - (am*k*log((H1 + Iin)/(H1 + Iin*exp(-L1*(kbg1 + X1*k)))))/(L1*(kbg1 + X1*k)^2);
dA2dX2=(Iin*am*k*exp(-L2*(kbg2 + X2*k)))/((H1 + Iin*exp(-L2*(kbg2 + X2*k)))*(kbg2 + X2*k)) - (am*k*log((H1 + Iin)/(H1 + Iin*exp(-L2*(kbg2 + X2*k)))))/(L2*(kbg2 + X2*k)^2);
dA1dY1=0;
dA2dY2=0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Df1DX1=(X1*Y1*c1^2*h0)/(X1*c1*h0 + Y1*h0*w + 1)^2 - (Y1*c1)/(X1*c1*h0 + Y1*h0*w + 1) - d1 + (Y1*afa*am*log((H1 + Iin)/(H1 + Iin*exp(-L1*(kbg1 + X1*k)))))/(L1*(Y1 + beta)*(kbg1 + X1*k)) - (X1*Y1*afa*am*k*log((H1 + Iin)/(H1 + Iin*exp(-L1*(kbg1 + X1*k)))))/(L1*(Y1 + beta)*(kbg1 + X1*k)^2) + (Iin*X1*Y1*afa*am*k*exp(-L1*(kbg1 + X1*k)))/((Y1 + beta)*(H1 + Iin*exp(-L1*(kbg1 + X1*k)))*(kbg1 + X1*k));
Df1DX2=0;
Df1DY1=(X1*Y1*c1*h0*w)/(X1*c1*h0 + Y1*h0*w + 1)^2 - (X1*c1)/(X1*c1*h0 + Y1*h0*w + 1) + (X1*afa*am*log((H1 + Iin)/(H1 + Iin*exp(-L1*(kbg1 + X1*k)))))/(L1*(Y1 + beta)*(kbg1 + X1*k)) - (X1*Y1*afa*am*log((H1 + Iin)/(H1 + Iin*exp(-L1*(kbg1 + X1*k)))))/(L1*(Y1 + beta)^2*(kbg1 + X1*k));
Df1DY2=0;
Df1DZ =0;
Df1DTH=0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Df2DX1=0;
Df2DX2= (X2*Y2*c2^2*h0)/(X2*c2*h0 + Y2*h0*w + 1)^2 - (Y2*c2)/(X2*c2*h0 + Y2*h0*w + 1) - d2 + (Y2*afa*am*log((H1 + Iin)/(H1 + Iin*exp(-L2*(kbg2 + X2*k)))))/(L2*(Y2 + beta)*(kbg2 + X2*k)) - (X2*Y2*afa*am*k*log((H1 + Iin)/(H1 + Iin*exp(-L2*(kbg2 + X2*k)))))/(L2*(Y2 + beta)*(kbg2 + X2*k)^2) + (Iin*X2*Y2*afa*am*k*exp(-L2*(kbg2 + X2*k)))/((Y2 + beta)*(H1 + Iin*exp(-L2*(kbg2 + X2*k)))*(kbg2 + X2*k));
Df2DY1=0;
Df2DY2= (X2*Y2*c2*h0*w)/(X2*c2*h0 + Y2*h0*w + 1)^2 - (X2*c2)/(X2*c2*h0 + Y2*h0*w + 1) + (X2*afa*am*log((H1 + Iin)/(H1 + Iin*exp(-L2*(kbg2 + X2*k)))))/(L2*(Y2 + beta)*(kbg2 + X2*k)) - (X2*Y2*afa*am*log((H1 + Iin)/(H1 + Iin*exp(-L2*(kbg2 + X2*k)))))/(L2*(Y2 + beta)^2*(kbg2 + X2*k));
Df2DZ =0;
Df2DTH= 0;
 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%f(3)=-Y1*d1+c1*Y1*X1/(1+h0*c1*X1+h0*w*Y1)-Y1*b1*Z*TH/(1+h1*OMIGA1); %Y1
Df3DX1=(Y1*c1)/(X1*c1*h0 + Y1*h0*w + 1) - (X1*Y1*c1^2*h0)/(X1*c1*h0 + Y1*h0*w + 1)^2;
Df3DX2=0;
Df3DY1=(X1*c1)/(X1*c1*h0 + Y1*h0*w + 1) - d1 - (TH*Z*b1)/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1) + (TH^2*Y1*Z*b1^2*h1)/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1)^2 - (X1*Y1*c1*h0*w)/(X1*c1*h0 + Y1*h0*w + 1)^2;
Df3DY2=-(TH*Y1*Z*b1*b2*h1*(TH - 1))/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1)^2;
Df3DZ =-(TH*Y1*b1)/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1);
Df3DTH= (TH*Y1*Z*b1*h1*(Y1*b1 - Y2*b2))/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1)^2 - (Y1*Z*b1)/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1);
 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%f(4)=-Y2*d2+c2*Y2*X2/(1+h0*c2*X2+h0*w*Y2)-Y2*b2*Z*(1-TH)/(1+h1*OMIGA1); %Y2
Df4DX1=0;
Df4DX2=(Y2*c2)/(X2*c2*h0 + Y2*h0*w + 1) - (X2*Y2*c2^2*h0)/(X2*c2*h0 + Y2*h0*w + 1)^2;
Df4DY1= -(TH*Y2*Z*b1*b2*h1*(TH - 1))/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1)^2;
Df4DY2=(X2*c2)/(X2*c2*h0 + Y2*h0*w + 1) - d2 + (Z*b2*(TH - 1))/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1) - (X2*Y2*c2*h0*w)/(X2*c2*h0 + Y2*h0*w + 1)^2 + (Y2*Z*b2^2*h1*(TH - 1)^2)/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1)^2;
Df4DZ =(Y2*b2*(TH - 1))/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1);
Df4DTH=(Y2*Z*b2)/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1) - (Y2*Z*b2*h1*(Y1*b1 - Y2*b2)*(TH - 1))/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1)^2;
 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%f(5)=Z*(e1*OMIGA1/(1+h1*OMIGA1)-m1);    
Df5DX1=0;
Df5DX2=0;
Df5DY1=Z*((TH*b1*e1)/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1) - (TH*b1*e1*h1*(TH*Y1*b1 - Y2*b2*(TH - 1)))/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1)^2);
Df5DY2= -Z*((b2*e1*(TH - 1))/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1) - (b2*e1*h1*(TH*Y1*b1 - Y2*b2*(TH - 1))*(TH - 1))/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1)^2);
Df5DZ =(e1*(TH*Y1*b1 - Y2*b2*(TH - 1)))/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1) - m1;
Df5DTH= Z*((e1*(Y1*b1 - Y2*b2))/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1) - (e1*h1*(Y1*b1 - Y2*b2)*(TH*Y1*b1 - Y2*b2*(TH - 1)))/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1)^2);
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%f(6)=2*g1*TH*(1-TH)*e1*(b1*Y1-b2*Y2)/((1+h1*OMIGA1)^2);  
Df6DX1=0;
Df6DX2=0;
Df6DY1=(2*TH^2*b1*e1*g1*h1*(Y1*b1 - Y2*b2)*(TH - 1))/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1)^3 - (TH*b1*e1*g1*(TH - 1))/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1)^2;
Df6DY2= (TH*b2*e1*g1*(TH - 1))/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1)^2 - (2*TH*b2*e1*g1*h1*(Y1*b1 - Y2*b2)*(TH - 1)^2)/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1)^3;
Df6DZ = 0;
Df6DTH= (2*TH*e1*g1*h1*(Y1*b1 - Y2*b2)^2*(TH - 1))/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1)^3 - (e1*g1*(Y1*b1 - Y2*b2)*(TH - 1))/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1)^2 - (TH*e1*g1*(Y1*b1 - Y2*b2))/(h1*(TH*Y1*b1 - Y2*b2*(TH - 1)) + 1)^2;
 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
Jac = [Df1DX1 Df1DX2 Df1DY1 Df1DY2 Df1DZ Df1DTH;
       Df2DX1 Df2DX2 Df2DY1 Df2DY2 Df2DZ Df2DTH;
       Df3DX1 Df3DX2 Df3DY1 Df3DY2 Df3DZ Df3DTH;
       Df4DX1 Df4DX2 Df4DY1 Df4DY2 Df4DZ Df4DTH;
       Df5DX1 Df5DX2 Df5DY1 Df5DY2 Df5DZ Df5DTH;
       Df6DX1 Df6DX2 Df6DY1 Df6DY2 Df6DZ Df6DTH];

 f(7:42)=Jac*Y;