clear,clc
Z1=[ ];Z2=[ ];Z3=[ ];Z4=[ ];Z5=[ ];Z6=[ ];C=[ ];
global d;
tic
for d=0:0.005:1
   d
   [T,Res,M]=lyapunov(6,@bird_jac,@ode45,0,1,20000,[6 5 2 1 4 0.5],500);
    Z1=[Z1;M(1)]; 
    Z2=[Z2;M(2)]; 
    Z3=[Z3;M(3)]; 
    Z4=[Z4;M(4)]; 
    Z5=[Z5;M(5)]; 
    Z6=[Z6;M(6)]; 
    C=[C;d];
    toc
end

hold on
 d=0:0.005:1;
line(d,0,'Color','k','LineWidth',5);
yline(0,'--','LineWidth',2);
plot(C,Z1,'r',C,Z2,'b',C,Z3,'g',C,Z4,'m',C,Z5,'k',C,Z6,'c')
set(gca,'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20 ,'LineWidth',3,'XTick',[0 0.2 0.4 0.6 0.8 1 ])
xlabel('\itg','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
ylabel('Lyapunov exponents','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
ylim([-0.008 0.008]);
yticks(-0.008:0.002:0.008);
xlim([0 0.8]);
xticks(0:0.2:0.8);


box on 