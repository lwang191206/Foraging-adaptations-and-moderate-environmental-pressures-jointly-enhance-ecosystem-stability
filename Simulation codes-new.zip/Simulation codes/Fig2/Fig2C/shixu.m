clc;clear;
global d1;global d2;
global c1;global c2;
global p1;global p2;
global q1;global q2;
global b1;global b2;
global e1;global m1;global am;global k;
global H1;global Iin;global h1;
global g1;global kbg1;global kbg2;
global L1;global L2;
global afa;global beta;
%%%%%%%%%%%%%模型参数%%%%%%%%%%
 d=0.10;d1=d;d2=d;
c1=0.3;p1=c1;
c2=0.35;p2=c2;
b1=0.25;b2=0.3;
e1=.5;m1=0.1;am=1;
k=.2;H1=1;beta=.1;
%%%%%%%%% 关键参数 %%%%%%%%%%%%%%%%%%
g1=0;                              % 适应强度 0-1
afa=0.75;                            % 出芽率  0.68--0.75
h1=1;                                % 处理时间  0-1
w=0.5;    q1=w; q2=w;                % 干扰强度  0.5-1
kbg=.5;    kbg1=kbg;kbg2=kbg;       % 浑浊度   0.5-0.85
Iin=1;                               % 光强度 0.85-1
L=1;      L1=L;L2=L;                 % 水位  1-1.35
%%%%%%%% 初始值 %%%%%%%%%%%%%%%%%%%
ox1=6; ox2=5; oy1=2; oy2=1; oz1=4; ou1=0.5; 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%模型计算
[t1,y]=ode45(@full_module,[0:100:20000],[ox1 ox2 oy1 oy2 oz1 ou1]);
        %绘图

subplot(2,2,1);plot(t1,y(:,5),'LineWidth', 2);
set(gca,'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20, 'LineWidth',3);
title('\its=0.5','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
ylabel('Z','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);

ylim([0 12]);
yticks(0:4:12);
xlim([0 20000]);

subplot(2,2,2);
plot(t1,y(:,6),'b','LineWidth', 2);
set(gca,'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20, 'LineWidth',3);
ylabel('Theta','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
title('\its=0.5','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
xlim([0 20000]);
ylim([0 1]);
yticks(0:0.25:1);


%%%%%%%5%%55%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;clear;
global d1;global d2;
global c1;global c2;
global p1;global p2;
global q1;global q2;
global b1;global b2;
global e1;global m1;global am;global k;
global H1;global Iin;global h1;
global g1;global kbg1;global kbg2;
global L1;global L2;
global afa;global beta;
%%%%%%%%%%%%%模型参数%%%%%%%%%%
 d=0.10;d1=d;d2=d;
c1=0.3;p1=c1;
c2=0.35;p2=c2;
b1=0.25;b2=0.3;
e1=.5;m1=0.1;am=1;
k=.2;H1=1;beta=.1;
%%%%%%%%% 关键参数 %%%%%%%%%%%%%%%%%%
g1=0.3;                              % 适应强度 0-1
afa=0.75;                            % 出芽率  0.68--0.75
h1=1;                                % 处理时间  0-1
w=0.5;    q1=w; q2=w;                % 干扰强度  0.5-1
kbg=.5;    kbg1=kbg;kbg2=kbg;       % 浑浊度   0.5-0.85
Iin=1;                               % 光强度 0.85-1
L=1;      L1=L;L2=L;                 % 水位  1-1.35
%%%%%%%% 初始值 %%%%%%%%%%%%%%%%%%%
ox1=6; ox2=5; oy1=2; oy2=1; oz1=4; ou1=0.5; 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%模型计算
[t1,y]=ode45(@full_module,[0:100:20000],[ox1 ox2 oy1 oy2 oz1 ou1]);
        %绘图

subplot(2,2,3);plot(t1,y(:,5),'LineWidth', 2);
set(gca,'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20, 'LineWidth',3);
title('\its=0.7','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
ylabel('Z','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
xlabel('\itTime','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
ylim([0 12]);
yticks(0:4:12);
xlim([0 20000]);

subplot(2,2,4);
plot(t1,y(:,6),'b','LineWidth', 2);
set(gca,'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20, 'LineWidth',3);
ylabel('Theta','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
xlabel('\itTime','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
title('\its=0.7','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
xlim([0 20000]);
ylim([0 1]);
yticks(0:0.25:1);

