clc;
clear;
%%11111111
warning('off', 'all');

% w=0.5;    q1=w; q2=w;                % 干扰强度  0.5-1
for rr=linspace(0.37,1,127) 
ox1=6; ox2=5; oy1=2; oy2=1;oz1=4; ou1=0.5;     
d1=0.1;d2=0.1;c1=0.3;c2=0.35;h0=1;b1=0.25;b2=0.3;
e1=0.5;m1=0.1;am=1; k=0.2;H1=1;beta=0.1;
%%%%%%%%%%%%%%%%%%%%%%%%%%
g1=0.1;afa=0.75;h1=1;w=rr;
kbg1=0.5;kbg2=0.5;
Iin=1;
L1=1;L2=1;
[t,y]=ode45('Kucao',[0 5000],[ox1;ox2;oy1;oy2;oz1;ou1;
                               d1;d2;c1;c2;h0;w;b1;b2;
                               h1;e1;m1;g1;am;kbg1;kbg2;
                               k;L1;L2;H1;Iin;afa;beta]); 
subplot(2,2,1)                     
[Xmax]=getmax(y(:,5));
plot(rr,Xmax,'r.','markersize',8)
set(gca,'LineWidth',3,'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
ylabel('\itZ','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
xlim([0.4 1]);
ylim([2 8]);
yticks(2:2:8);
hold on
clear Xmax
subplot(2,2,3)                     
[Xmax]=getmax(y(:,6));
plot(rr,Xmax,'b.','markersize',8)
set(gca,'LineWidth',3,'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
xlabel('\itw','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
ylabel('\theta','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
xlim([0.4 1]);
ylim([0.4 1]);
yticks(0.4:0.2:1);
hold on
clear Xmax
end


%%
%3333333333333333
% afa=0.75;                            % 出芽率  0.68--0.75
for rr=linspace(0.68,0.92,121)
ox1=6; ox2=5; oy1=2; oy2=1;oz1=4; ou1=0.5;     
d1=0.1;d2=0.1;c1=0.3;c2=0.35;h0=1;b1=0.25;b2=0.3;
e1=0.5;m1=0.1;am=1; k=0.2;H1=1;beta=0.1;
%%%%%%%%%%%%%%%%%%%%%%%%%%
g1=0.1;afa=rr;h1=1;w=0.5;
kbg1=0.5;kbg2=0.5;
Iin=1;
L1=1;L2=1;
[t,y]=ode45('Kucao',[0 5000],[ox1;ox2;oy1;oy2;oz1;ou1;
                               d1;d2;c1;c2;h0;w;b1;b2;
                               h1;e1;m1;g1;am;kbg1;kbg2;
                               k;L1;L2;H1;Iin;afa;beta]); 
subplot(3,2,3)                     
[Xmax]=getmax(y(:,5));
plot(rr,Xmax,'r.','markersize',8)
set(gca,'LineWidth',3,'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
ylim([2 8]);
yticks(2:2:8);
hold on
clear Xmax
subplot(3,2,6)                     
[Xmax]=getmax(y(:,6));
plot(rr,Xmax,'b.','markersize',8)
set(gca,'LineWidth',3,'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
ylim([0.4 1]);
yticks(0.4:0.6:1);
xlabel('\alpha','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
hold on
clear Xmax
end


%%4444444444444444444
% kbg=.5;    kbg1=kbg;kbg2=kbg;       % 浑浊度   0.5-0.85
for rr=linspace(0,0.85,171)
ox1=6; ox2=5; oy1=2; oy2=1;oz1=4; ou1=0.5;     
d1=0.1;d2=0.1;c1=0.3;c2=0.35;h0=1;b1=0.25;b2=0.3;
e1=0.5;m1=0.1;am=1; k=0.2;H1=1;beta=0.1;
%%%%%%%%%%%%%%%%%%%%%%%%%%
g1=0.1;afa=0.75;h1=1;w=0.5;
kbg1=rr;kbg2=rr;
Iin=1;
L1=1;L2=1;
[t,y]=ode45('Kucao',[0 5000],[ox1;ox2;oy1;oy2;oz1;ou1;
                               d1;d2;c1;c2;h0;w;b1;b2;
                               h1;e1;m1;g1;am;kbg1;kbg2;
                               k;L1;L2;H1;Iin;afa;beta]); 
subplot(4,3,7)                     
[Xmax]=getmax(y(:,5));
plot(rr,Xmax,'r.','markersize',8)
set(gca,'LineWidth',3,'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
xlabel('\itK_b_g','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
ylabel('Z','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
hold on
clear Xmax
subplot(4,3,10)                     
[Xmax]=getmax(y(:,6));
plot(rr,Xmax,'b.','markersize',8)
set(gca,'LineWidth',3,'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
xlabel('\itK_b_g','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
ylabel('\theta','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
hold on
clear Xmax
end

%5555555555555555555555
% Iin=1;                               % 光强度 0.85-1
for rr=linspace(0.85,1.34,99)
ox1=6; ox2=5; oy1=2; oy2=1;oz1=4; ou1=0.5;     
d1=0.1;d2=0.1;c1=0.3;c2=0.35;h0=1;b1=0.25;b2=0.3;
e1=0.5;m1=0.1;am=1; k=0.2;H1=1;beta=0.1;
%%%%%%%%%%%%%%%%%%%%%%%%%%
g1=0.1;afa=0.75;h1=1;w=0.5;
kbg1=0.5;kbg2=0.5;
Iin=rr;
L1=1;L2=1;
[t,y]=ode45('Kucao',[0 5000],[ox1;ox2;oy1;oy2;oz1;ou1;
                               d1;d2;c1;c2;h0;w;b1;b2;
                               h1;e1;m1;g1;am;kbg1;kbg2;
                               k;L1;L2;H1;Iin;afa;beta]); 
subplot(4,3,8)                     
[Xmax]=getmax(y(:,5));
plot(rr,Xmax,'r.','markersize',8)
set(gca,'LineWidth',3,'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
xlabel('\itI_i_n','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
ylabel('Z','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
hold on
clear Xmax
subplot(4,3,11)                     
[Xmax]=getmax(y(:,6));
plot(rr,Xmax,'b.','markersize',8)
set(gca,'LineWidth',3,'Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 20);
xlabel('\itI_i_n','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
ylabel('\theta','Fontname', 'Arial', 'Fontweight', 'bold', 'FontSize', 25);
hold on
clear Xmax
end

